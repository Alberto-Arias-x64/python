from setuptools import setup

setup(
	name="praticas",
	version="1.0",
	description="hoarana",
	author="simio",
    packages=["calculos"]
	)
