def sumar (n1,n2):
	return(n1+n2)

def restar (n1,n2):
	return(n1-n2)

def multiplicar (n1,n2):
	return(n1*n2)

def dividir (n1,n2):
	return(n1/n2)